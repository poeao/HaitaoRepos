who(){
          echo " I am $1."
}
who $1
