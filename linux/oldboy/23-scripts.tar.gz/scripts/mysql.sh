#!/bin/sh
#oldboy linux by xiedi 

#no1
if [ $# -ne 1 ] 
   then
   echo "USAGE:/data/3306/$0 {start|stop}"
   exit 1
fi
#no2
if [ "$1" == "start" ] 
  then
  /bin/sh /application/mysql/bin/mysqld_safe --defaults-file=/data/3306/my.cnf 2>&1 > /dev/null &
  exit 0
fi
#no3
if [ "$1" == "stop" ]
  then
  mysqladmin -u root -poldboy123 -S /data/3306/mysql.sock shutdown
  exit 0
fi





