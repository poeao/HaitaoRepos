#!/bin/sh
usage(){
 echo "USAGE:$0 arg"
 exit 1
}

check_web(){
curl -s $1 &>/dev/null
if [ $? -eq 0 ]
 then
    echo "$1 web is ok"
else 
    echo "$1 web is no"
fi
}
main(){
  if [ $# -ne 1 ]
  then
   usage
  fi
  check_web $1
}
main $*
