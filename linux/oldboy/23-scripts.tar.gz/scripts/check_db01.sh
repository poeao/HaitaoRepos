#!/bin/sh
port=`ps -ef|grep mysql|grep -v grep|wc -l`
#port=`lsof -i:3307|grep mysql|wc -l`
#port=`ss -lntup|grep mysql|wc -l`
#port=`netstat -lntup|grep mysql|wc -l`
if [ $port -ne 2 ];then
   echo "MySQL is not running"
else
   echo "MySQL is running"
fi
