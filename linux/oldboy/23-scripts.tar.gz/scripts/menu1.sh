#!/bin/sh

#no.1 menu
cat <<EOF
    1.[install lamp]
    2.[install lnmp]
    3.[exit]
EOF
#no.2
read -t 20 -p " pls input the num you want:" num
[ "$num" != "1" -a  "$num" != "2" -a  "$num" != "3" ]&&{
 echo "Input error"
 exit
}
#no.3
[ $num -eq 1 ]&&{
 echo "install lamp"
 [ -f /server/scripts/lamp.sh ]&&\
 /bin/sh /server/scripts/lamp.sh
 exit
}
[ $num -eq 2 ]&&{
 echo "install lnmp"
[ -f /server/scripts/lnmp.sh ]&&\
 /bin/sh /server/scripts/lnmp.sh
 exit
}

[ $num -eq 3 ]&&{
 echo "bye!"
 exit
}
