#!/bin/sh
MYUSER=root
MYPASS=oldboy123
[ ! -d /server/backup/ ] && mkdir /server/backup/ -p
SOCKET=/data/3306/mysql.sock
MYCMD="mysql -u$MYUSER -p$MYPASS -S $SOCKET"
MYDUMP="mysqldump -u$MYUSER -p$MYPASS -S $SOCKET"
for database in `$MYCMD -e "show databases;"|sed '1,2d'|egrep -v "mysql|per"`
do 
  $MYDUMP $database|gzip >/server/backup/${database}_$(date +%F).sql.gz
done
