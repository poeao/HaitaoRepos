#!/bin/bash
read -p "pls input two num:" a b
#no.1 judge read.
[ -z "$a" ]||[ -z "$b" ] && {                
    echo "pls input two num agagin"
    exit 1
}

#no.2 judge if int
expr $a + 1 &>/dev/null
RETVAL1=$?
expr $b + 1 &>/dev/null
RETVAL2=$?
if [ $RETVAL1 -ne 0 -a $RETVAL2 -ne 0 ];then
	echo "please input two int again"
	exit 3
fi

if [ $RETVAL1 -ne 0 ];then
	echo "The first num is not int,please input again"
	exit 4
fi

if [ $RETVAL2 -ne 0 ];then
	echo "The second num is not int,please input again"
	exit 5
fi

#no.3 compart two num.
if [ $a -lt $b ];then
	echo "$a<$b"
	exit
elif [ $a -eq $b ];then
	echo "$a=$b"
	exit
else
	echo "$a>$b"
fi
