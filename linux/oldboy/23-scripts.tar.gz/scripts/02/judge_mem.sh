#/bin/sh
cur_free=`free -m|awk '/buffers\// {print $NF}'`
chars="current memory is  $cur_free."
if [ $cur_free -lt 800 ]
  then
    echo $chars
    echo $chars|mail -s "$chars" 2934145242@qq.com
fi

