#!/bin/sh
file1=/etc/hosts
if [ -f "$file1" ]
then
 echo 1
else
 echo 0
fi
