#!/bin/sh
[ -f /tmp/oldboy.log ]&&{
 cat /tmp/oldboy.log 
 echo 1
 exit
}
