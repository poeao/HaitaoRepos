#!/bin/sh
if [ -f /etc/hosts ]
 then
   echo 1
fi
