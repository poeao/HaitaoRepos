#!/bin/bash
#no.1 judge arg nums.
if [ $# -ne 2 ];then
	echo "USAGE:$0 arg1 arg2"
	exit 2
fi

#no.2 judge if int
expr $1 + 1 &>/dev/null
RETVAL1=$?
expr $2 + 1 &>/dev/null
RETVAL2=$?
if [ $RETVAL1 -ne 0 -a $RETVAL2 -ne 0 ];then
	echo "please input two int again"
	exit 3
fi

if [ $RETVAL1 -ne 0 ];then
	echo "The first num is not int,please input again"
	exit 4
fi

if [ $RETVAL2 -ne 0 ];then
	echo "The second num is not int,please input again"
	exit 5
fi

#no.3 compart two num.
if [ $1 -lt $2 ];then
	echo "$1<$2"
	exit
elif [ $1 -eq $2 ];then
	echo "$1=$2"
	exit
else
	echo "$1>$2"
fi
