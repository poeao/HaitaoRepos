for n in I am oldboy linux welcome to our training.
do
   if [ ${#n} -lt 6 ]
    then
      echo $n
   fi
done
