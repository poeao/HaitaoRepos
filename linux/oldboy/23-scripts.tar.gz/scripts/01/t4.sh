
find ${path:-/tmp} -name "mong*"|xargs rm -f
