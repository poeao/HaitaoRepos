#!/bin/sh
[ $# -ne 2 ] && {
  echo "$0 ARG1 ARG2"
  exit 48
}
echo oldboy
