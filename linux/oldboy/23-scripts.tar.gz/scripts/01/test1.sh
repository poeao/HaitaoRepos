#!/bin/bash
echo "a-b =$(( $1 - $2 ))"
echo "a+b =$(( $1 + $2 ))"
echo "a*b =$(( $1 * $2 ))"
echo "a/b =$(( $1 / $2 ))"
echo "a**b =$(( $1 ** $2 ))"
echo "a%b =$(( $1 % $2 ))"

