read -p "Pls input:" a
expr $a + 1 &>/dev/null
[ $? -eq 0 ] && echo int||echo chars

