oldboy(){
echo "I am oldboy linux"
return $?
}
oldboy
