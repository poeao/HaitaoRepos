kill `cat /tmp/a.pid`
sleep 2
echo $$ >/tmp/a.pid
sleep 300
