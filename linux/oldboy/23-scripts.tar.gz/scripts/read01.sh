#!/bin/sh
read -t 5 -p "Pls input a character:" a
echo "your input is: $a"
