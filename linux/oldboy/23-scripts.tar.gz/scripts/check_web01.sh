port=`curl -s -I 10.0.0.5|head -1|grep "\b200\b"|wc -l`
#port=`curl --connect-timeout 5 http://10.0.0.5 &>/dev/null`
#port=`wget -T 10 --spider -t 2 http://10.0.0.5 &>/dev/null`
#if [  $port -ne 1 ];then
#if [ $port -ne 1 ];then
if [ "`curl -I -s -w "%{http_code}\n" 10.0.0.5 -o /dev/null`" != "200" ]
then
   echo "httpd is not running"
else
   echo "httpd is running"
fi
