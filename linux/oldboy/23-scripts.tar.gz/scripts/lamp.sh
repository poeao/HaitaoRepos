echo lamp is installed
