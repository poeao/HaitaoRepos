#!/bin/sh
check_url(){
wget -T 10 --spider -t 2 $1 &>/dev/null
RETVAL=$?
if [ $RETVAL -eq 0 ]
then
   echo "$1 is ok."
else
   echo "$1 is no."
fi
return $RETVAL
}
check_url $1
