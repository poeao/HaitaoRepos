port=`echo -e "\n"|telnet 10.0.0.5 3307 2>/dev/null|grep Connected|wc -l`
#port=`nc -w 5 10.0.0.5 3307 &>/dev/null`
#port=`nmap 10.0.0.5 -p 3307|grep open|wc -l`
#if [ $? -ne 0 ];then
if [ $port -ne 1 ];then
   echo "MySQL is not running"
else
   echo "MySQL is running"
fi
