menu (){
cat <<AA
============================
     1.[instatll lamp]
     2.[instatll lnmp]     
     3.[exit]   
============================
AA
echo -n "pls input the num you want:"
read -t 10 a
}

Read (){
[ $a -eq 1 ]&&{
  echo start installing lamp.
#DO SOMETHING
  sleep 1
  echo '#######################'
  echo '#  lamp is installed  #'
  echo '#######################'
  sleep 2
  clear
menu
Read
}

[ $a -eq 2 ] && {
  echo start installing lnmp.
#DO SOMETHING
  sleep 1
  echo '#######################'
  echo '#  lamp is installed  #'
  echo '#######################'
  sleep 2
  clear
menu
Read
}

[ $a -eq 3 ] && {
  exit 0
}
}
#[ ! $a -eq 1,2,3 ] && echo '0.0' && exit
menu
Read
[ $a != 1,2,3 ] && echo 'Input error' && exit 1

