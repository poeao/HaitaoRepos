#!/bin/sh

#no.1 judge arg nums.
[ $# -ne 2 ]&&{
  echo "USAGE:"$0" num1 num2"
  exit 1
}
#no.2 judge if int.
expr $1 + 1 &>/dev/null
RETVAL1=$?
expr $2 + 1 &>/dev/null
RETVAL2=$?

[ $RETVAL1 -ne 0 -a $RETVAL2 -ne 0 ]&&{
 echo "pls input two nums."
 exit 2
}


[ $RETVAL1 -ne 0 ]&&{
 echo "The first num is not int,pls input again."
 exit 2
}
[ $RETVAL2 -ne 0 ]&&{
 echo "The second num is not int,pls input again."
 exit 3
}

#no.3  compare two int.
[ $1 -lt $2 ]&&{
  echo "$1<$2"
  exit 0
}

[ $1 -eq $2 ]&&{
  echo "$1=$2"
  exit 0
}
[ $1 -gt $2 ]&&{
  echo "$1>$2"
  exit 0
}

