#!/bin/bash
###################################################################################
# File Name	: menu.sh
# Description	: 
# Language	: English
# Version	: 0.1
# Author	: guo yuming
# Mail		: shmilyjinian@163.com
# Created Time	: 2015-06-20 09:39:02 PM
###################################################################################
Red='\033[31;1m'
Green='\033[32;1m'
Yellow='\033[33;1m'
Blue='\033[34;1m'
Purple='\033[35;1m'
Cyan='\033[36;1m'
Flashing='\033[31;5m'
Normal='\033[0;1m'
Sys_info='System information'
Con_hostname='Hostname'
Con_net='Network' 
Con_other='Other'
Service1='NFS'
Service2='rsync'
Service3='Apache'
Service4='Nginx'
Service5='MySql'
Service6='PHP'
Service7='RPC'
Warning(){
echo -e "$Red=================================================================================$Normal"
echo -e "$Red|$Normal    		   		    $Flashing\aWarning!!!$Normal    				$Red|$Normal"
echo -e "$Red|$Normal 			Invalid input, please input again			$Red|$Normal"
echo -e "$Red=================================================================================$Normal"
}
Level1_menu(){
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   1   $Normal $Yellow|$Normal $Cyan $Sys_info  $Normal                              			$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   2   $Normal $Yellow|$Normal $Cyan Configure $Con_hostname  $Normal                              			$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   3   $Normal $Yellow|$Normal $Cyan Configure $Con_net Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   4   $Normal $Yellow|$Normal $Cyan Configure $Con_other Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red  10   $Normal $Yellow|$Normal $Cyan [10|p|P|print] Print the current menu $Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red  11   $Normal $Yellow|$Normal $Cyan [11|q|Q|exit] quit script $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
}
Host_level2_menu(){
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   1   $Normal $Yellow|$Normal $Cyan Temporary configuration $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   2   $Normal $Yellow|$Normal $Cyan Permanent configuration $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   3   $Normal $Yellow|$Normal $Cyan [3|p|P|print] Print the current menu $Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   4   $Normal $Yellow|$Normal $Cyan [4|b|B|back] Return to the superior menu $Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   5   $Normal $Yellow|$Normal $Cyan [5|q|Q|exit] quit script $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
}
Net_level2_menu(){
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   1   $Normal $Yellow|$Normal $Cyan Display $Con_net information $Normal					$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   2   $Normal $Yellow|$Normal $Cyan Configuration $Con_net $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   3   $Normal $Yellow|$Normal $Cyan Status $Con_net service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   4   $Normal $Yellow|$Normal $Cyan Start $Con_net service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   5   $Normal $Yellow|$Normal $Cyan Stop $Con_net service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   6   $Normal $Yellow|$Normal $Cyan Restart $Con_net service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   7   $Normal $Yellow|$Normal $Cyan Reload $Con_net service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   8   $Normal $Yellow|$Normal $Cyan [8|p|P|print] Print the current menu $Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   9   $Normal $Yellow|$Normal $Cyan [9|b|B|back] Return to the superior menu $Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red  10   $Normal $Yellow|$Normal $Cyan [10|q|Q|exit] quit script $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
}
Other_level2_menu(){
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   1   $Normal $Yellow|$Normal $Cyan Configure $Service1 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   2   $Normal $Yellow|$Normal $Cyan Configure $Service2 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   3   $Normal $Yellow|$Normal $Cyan Configure $Service3 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   4   $Normal $Yellow|$Normal $Cyan Configure $Service4 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   5   $Normal $Yellow|$Normal $Cyan Configure $Service5 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   6   $Normal $Yellow|$Normal $Cyan Configure $Service6 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red  10   $Normal $Yellow|$Normal $Cyan [10|p|P|print] Print the current menu $Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red  11   $Normal $Yellow|$Normal $Cyan [11|b|B|back] Return to the superior menu$Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red  12   $Normal $Yellow|$Normal $Cyan [12|q|Q|exit] quit script $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
}

NFS_level3_menu(){
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   1   $Normal $Yellow|$Normal $Cyan $Service7 Service $Normal							$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   2   $Normal $Yellow|$Normal $Cyan $Service1 Service $Normal							$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   3   $Normal $Yellow|$Normal $Cyan [3|p|P|print] Print the current menu $Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   4   $Normal $Yellow|$Normal $Cyan [4|b|B|back] Return to the superior menu$Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   5   $Normal $Yellow|$Normal $Cyan [5|q|Q|exit] quit script $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
}
RPC_level4_menu(){
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   1   $Normal $Yellow|$Normal $Cyan Install $Service7 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   2   $Normal $Yellow|$Normal $Cyan Uninstall $Service7 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   3   $Normal $Yellow|$Normal $Cyan Configure $Service7 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   4   $Normal $Yellow|$Normal $Cyan Status $Service7 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   5   $Normal $Yellow|$Normal $Cyan Start $Service7 Service $Normal							$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   6   $Normal $Yellow|$Normal $Cyan Stop $Service7 Service $Normal							$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   7   $Normal $Yellow|$Normal $Cyan Restart $Service7 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   8   $Normal $Yellow|$Normal $Cyan Reload $Service7 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   9   $Normal $Yellow|$Normal $Cyan [9|p|P|print] Print the current menu $Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red  10   $Normal $Yellow|$Normal $Cyan [10|b|B|back] Return to the superior menu$Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red  11   $Normal $Yellow|$Normal $Cyan [11|q|Q|exit] quit script $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
}
NFS_level4_menu(){
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   1   $Normal $Yellow|$Normal $Cyan Install $Service1 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   2   $Normal $Yellow|$Normal $Cyan Uninstall $Service1 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   3   $Normal $Yellow|$Normal $Cyan Configure $Service1 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   4   $Normal $Yellow|$Normal $Cyan Status $Service1 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   5   $Normal $Yellow|$Normal $Cyan Start $Service1 Service $Normal							$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   6   $Normal $Yellow|$Normal $Cyan Stop $Service1 Service $Normal							$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   7   $Normal $Yellow|$Normal $Cyan Restart $Service1 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   8   $Normal $Yellow|$Normal $Cyan Reload $Service1 Service $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red   9   $Normal $Yellow|$Normal $Cyan [10|p|P|print] Print the current menu $Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red  10   $Normal $Yellow|$Normal $Cyan [11|b|B|back] Return to the superior menu$Normal				$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
echo -e "$Yellow|$Normal $Red  11   $Normal $Yellow|$Normal $Cyan [12|q|Q|exit] quit script $Normal						$Yellow|$Normal"
echo -e "$Yellow=================================================================================$Normal"
}


main (){
echo -e "$Green Welcome to use the service configure script$Normal"
Level1_menu
while true
do
read -p "Please enter the serial number : " Input1
case $Input1 in
  1)
#system infomation
	;;
  2)
#configure hostname
	Host_level2_menu
	while true
	do
	read -p "Please enter your choice: " Input2
	case $Input2 in
	  1)
		echo "临时配置"
		;;
	  2)
		echo "永久配置"
		;;
	  3|p|P|print)
	  	Host_level2_menu
		;;
	  4|b|B|back)
		Level1_menu
		break
		;;
	  5|q|Q|exit)
		echo quitting.......
		exit 0
		;;
	  *)
		Warning
		Host_level2_menu
	esac
	done
	;;
  3)
# configure network service
	Net_level2_menu
	while true
	do
	read -p "Please enter your choice: " Input3
	case $Input3 in
	  1|ifconfig)
		/sbin/ifconfig -a
		;;
	  2|setup)
	  	setup
		;;
	  3|status)
	  	/etc/init.d/network status
		;;
	  4|start)
	  	/etc/init.d/network start
		;;
	  5|stop)
	  	/etc/init.d/network stop
		;;
	  6|restart)
	  	/etc/init.d/network restart
		;;
	  7|reload)
	  	/etc/init.d/network reload
		;;
	  8|p|P|print)
	  	Net_level2_menu
		;;
	  9|b|B|back)
	  	Level1_menu
		break
		;;
	  10|q|Q|exit)
	  	echo "quitting......"
		exit 0
		;;
	  *)
	  	Warning
	  	Net_level2_menu
	esac
	done
	;;
  4)
#configure other service (rpc,nfs,rsync,apache,nginx,mysql,php)
	Other_level2_menu
	while true
	do
	read -p "Please enter the serial number of the service needs to be configure: " Input4
	case $Input4 in 
	  1)
	  #. /server/scripts/nfsmenu.sh
	  #configure nfs
	  	NFS_level3_menu
		while true
		do
		read -p "Please enter your choice: " Input4_1
		case $Input4_1 in
		  1)
		  #configure rpc
		  	RPC_level4_menu
			while true
			do
			read -p "Please enter your choice: " Input4_1_1
			case $Input4_1_1 in
			  1)
			  	echo "安装rpc"
			  	;;
			  2)
			  	echo "卸载rpc"
				;;
			  3)
			  	echo "配置rpc"
				;;
			  4)
			  	/etc/init.d/rpcbind status
				;;
			  5)
				/etc/init.d/rpcbind start
				;;
			  6)
			  	/etc/init.d/rpcbind stop
				;;
			  7)
			  	/etc/init.d/rpcbind restart
				;;
			  8)
			  	/etc/init.d/rpcbind reload
				;;
			  9|p|P|print)
		  		RPC_level4_menu
				;;
			  10|b|B|back)
			  	NFS_level3_menu
				break
				;;
			  11|q|Q|quit)
			  	echo "quitting......"
				exit 0
				;;
			  *)
			  	Warning
				RPC_level4_menu
			esac
			done
			;;
		  2)
		  #configure nfs
		  	NFS_level4_menu
			while true
			do
			read -p "Please enter your choice: " Input4_1_2
			case $Input4_1_2 in
			  1)
			  	echo "安装nfs"
			  	;;
			  2)
			  	echo "卸载nfs"
				;;
			  3)
			  	echo "配置nfs"
				;;
			  4)
			  	/etc/init.d/nfs status
				;;
			  5)
				/etc/init.d/nfs start
				;;
			  6)
			  	/etc/init.d/nfs stop
				;;
			  7)
			  	/etc/init.d/nfs restart
				;;
			  8)
			  	/etc/init.d/nfs reload
				;;
			  9|p|P|print)
		  		NFS_level4_menu
				;;
			  10|b|B|back)
			  	NFS_level3_menu
				break
				;;
			  11|q|Q|quit)
			  	echo "quitting......"
				exit 0
				;;
			  *)
			  	Warning
				NFS_level4_menu
			esac
			done
			;;
		  3|p|P|print)
		  	NFS_level3_menu
			;;
		  4|b|B|back)
		  	Other_level2_menu
			break
			;;
		  5|q|Q|exit)
		  	echo "quitting......"
			exit 0
			;;
		  *)
		  	Warning
			NFS_level3_menu
		esac
		done
		;;
	  2)
	  #configure rsync
	  	;;
	  3)
	  #configure apache
	  	;;
	  4)
	  #configure nginx
	  	;;
	  5)
	  #configure mysql
	  	;;
	  6)
	  #configure php
	  	;;
	  7)
	  	;;
	  8)
	  	;;
	  10|p|P|print)
	  	Other_level2_menu
		;;
	  11|b|B|back)
		Level1_menu
		break
		;;
	  12|q|Q|exit)
		echo quitting.......
		exit 0
		;;
	  *)
		Warning
		Other_level2_menu
	esac
	done
	;;
  10|p|P|print)
  	Level1_menu
	;;
  11|q|Q|exit)
	echo "quitting........."
	exit 0
	;;
  *)
  	Warning
	Level1_menu
esac
done
}
main
