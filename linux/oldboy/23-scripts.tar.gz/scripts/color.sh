#!/bin/sh
RED_COLOR='\E[1;31m'
GREEN_COLOR='\E[1;32m'
YELLOW_COLOR='\E[1;33m'
BLUE_COLOR='\E[1;34m'
RES='\E[0m'
echo -e "$RED_COLOR oldboy $RES"
echo -e "$YELLOW_COLOR gongjie $RES"

