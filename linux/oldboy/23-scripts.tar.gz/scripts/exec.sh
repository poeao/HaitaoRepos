


sh ./func01.sh
oldboy
oldgirl
