#!/bin/bash
while true
do
	echo "it's ok"
	break
done
