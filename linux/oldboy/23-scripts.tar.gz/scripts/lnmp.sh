echo lnmp is installed
