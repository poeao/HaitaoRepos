#!/bin/sh
while true
 do
  uptime >>/tmp/a.log
  sleep 2
done
