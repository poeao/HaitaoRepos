package com.garavo.jacob;

import com.jacob.com.Dispatch;



public class Documents extends BaseWord{

	public Documents(Dispatch instance) {
		super(instance);
	}
}